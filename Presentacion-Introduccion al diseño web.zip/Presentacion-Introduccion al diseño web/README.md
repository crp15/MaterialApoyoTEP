# Introducción a Git

En esta presentación están descritos varios tópicos relacionados con el sistema de control de versiones git.

La presentación fue elaborada con la librería reveal.js, html5 y CSS3.
